File Description:

GTL: top copper
GBL: bottom copper
GTO: top silkscreen
GTP: top paste
GBO: bottom silkscreen
GTS: top solder mask
GBS: bottom solder mask
DRD: Drill file 1
Dri: Drill file 2


Solder Resist: YES
Silkscreen: NO
Non square: NO
2mm thick: NO
35u Copper: YES
SMD/GOLD: YES
<0.6mm: YES
Clearance < 10mil: YES
Test: NO

Delivery: 7 Days
Quantity: 45

Eleftherios Kampianakis
Tel: 6932702474
Office: 2821037426
